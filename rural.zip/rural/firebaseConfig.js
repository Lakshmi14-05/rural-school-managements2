// firebaseConfig.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCbBx0w1KkqzGzqUZIW38yQMYkZ2CbWCpU",
  authDomain: "rural-attendance-992ec.firebaseapp.com",
  projectId: "rural-attendance-992ec",
  storageBucket: "rural-attendance-992ec.firebasestorage.app",
  messagingSenderId: "449793474602",
  appId: "1:449793474602:web:b9316aa272178a11a80353",
  measurementId: "G-7M0N0L3RP5"
};


const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
